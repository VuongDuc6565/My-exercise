package hus.oop.students;

import java.util.List;

public class StudentManager {
    // Singleton pattern
    private static StudentManager instance;

    private List<Student> studentList;

    private StudentManager() {
        /* TODO */
    }

    public static StudentManager getInstance() {
        /* TODO */
    }

    /**
     * Thêm sinh viên vào cuối danh sách.
     * @param student
     */
    public void append(Student student) {
        /* TODO */
    }

    /**
     * Thêm sinh viên vào danh sách ở vị trí index.
     * @param student
     * @param index
     */
    public void add(Student student, int index) {
        /* TODO */
    }

    /**
     * Xóa sinh viên ở vị trí index.
     * @param index
     */
    public void remove(int index) {
        /* TODO */
    }

    /**
     * Lấy ra sinh viên ở vị trí index.
     * @param index
     * @return
     */
    public Student studentAt(int index) {
        /* TODO */
    }

    /**
     * Trả về số student trong danh sách.
     * @return
     */
    public int numberOfStudents() {
        /* TODO */
    }

    /**
     * Sắp xếp danh sách sinh viên theo thứ tự tăng dần theo tên,
     * nếu tên như nhau thì sắp xếp theo họ.
     * Sử dụng giao diện StudentComparable để sắp xếp.
     * @return
     */
    public List<Student> sortStudentsByName() {
        /* TODO */
    }

    /**
     * Trả về danh sách sinh viên sắp xếp theo thứ tự điểm trung bình tăng dần.
     * Sử dụng giao diện StudentComparator để sắp xếp.
     * Không làm thay đổi thứ tự sinh viên trong danh sách ban đầu.
     * @return
     */
    public List<Student> sortAverageGradeIncreasing() {
        /* TODO */
    }

    /**
     * Trả về danh sách sinh viên sắp xếp theo thứ tự điểm trung bình giảm dần.
     * Sử dụng giao diện StudentComparator để sắp xếp.
     * Không làm thay đổi thứ tự sinh viên trong danh sách ban đầu.
     * @return
     */
    public List<Student> sortAverageGradeDecreasing() {
        /* TODO */
    }

    /**
     * Lọc ra danh sách sinh viên có tất cả các điểm trên 4.0 và điểm trung bình trên 5.0.
     * @return
     */
    public List<Student> filterPassStudents() {
        /* TODO */
    }

    /**
     * Lọc ra danh sách sinh viên có ít nhất 1 môn dưới 4.0 hoặc điểm trung bình dưới 5.0.
     * @param howMany
     * @return
     */
    public List<Student> filterFailureStudents(int howMany) {
        /* TODO */
    }

    public static String idOfStudentsToString(List<Student> studentList) {
        StringBuilder idOfStudents = new StringBuilder();
        idOfStudents.append("[");
        for (Student country : studentList) {
            idOfStudents.append(country.getId()).append(" ");
        }
        return idOfStudents.toString().trim() + "]";
    }

    public static void print(List<Student> studentList) {
        StringBuilder studentsString = new StringBuilder();
        studentsString.append("[\n");
        for (Student student : studentList) {
            studentsString.append(student.toString()).append("\n");
        }
        System.out.print(studentsString.toString().trim() + "\n]");
    }
}

package hus.oop.students;

public interface StudentComparable {
    int compareTo(Student another);
}

package hus.oop.mynumbersystem;

public class ANumber {
    private String numberPresentation;  // Biểu diễn số
    private int radix;                  // Cơ số


    public ANumber(String originalNumber, int radix) {
        /* TODO */
    }

    public String getNumberPresentation() {
        /* TODO */
    }

    public void setNumberPresentation(String numberPresentation) {
        /* TODO */
    }

    public int getRadix() {
        /* TODO */
    }

    public void setRadix(int radix) {
        /* TODO */
    }
}
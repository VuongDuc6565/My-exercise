package hus.oop.decorator;

public class ThickcrustBread extends Bread {
  
	public ThickcrustBread() {
		description = "ThickcrustBread";
	}
  
	public double cost() {
		return 30.0;
	}
}


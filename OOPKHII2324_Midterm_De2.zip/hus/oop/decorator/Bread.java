package hus.oop.decorator;

public abstract class Bread {
	protected String description;
  
	public String getDescription() {
		/* TODO */
	}
 
	public abstract double cost();
}

package hus.oop.bookmanager;

public interface MyBookComparable {
    int compareTo(Book another);
}

package hus.oop.bookmanager;

public interface MyBookComparator {
    int compare(Book left, Book right);
}
